#define _CRT_SECURE_NO_DEPRECATE
#include "stdafx.h"


#include<stdio.h>

int    main(int argc,char *argv[])
        {  float t[32][35];
	     int i,j ,k;
           FILE *fin,*fout;

           fin = fopen(argv[1],"rb");   // Input file
           fout = fopen(argv[2],"w");     // Output file

           //fprintf(fout,"Daily Tempereture for 15 April 1980\n");
           if(fin == NULL)
           {  printf("Can't open file");
              return 0;
           }
           if(fout == NULL)
           {  printf("Can't open file");
              return 0;
           }
           for(k=0 ; k<365 ; k++)
           {  fread(&t,sizeof(t),1,fin) ;
              //if(k == 105)
                for(i=0 ; i < 32 ; i++)
	           {  fprintf(fout,"\n") ;
	              for(j=0 ; j < 35 ; j++)
                    fprintf(fout,"%6.2f",t[i][j]);
                 }
                
           }  
           fclose(fin);
           fclose(fout);
           return 0;
        } 